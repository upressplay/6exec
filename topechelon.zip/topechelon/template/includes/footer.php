<footer id="footer">
	
	<div id="footer_nav">
		<a href="http://6degreesinc.com/" target="_self">
			<div class="footer_nav_btn">
				home
			</div><!-- home -->
		</a>
		<a href="http://positions.6degreesinc.com/" target="_self">
			<div class="footer_nav_btn">
				positions
			</div><!-- positions -->
		</a>
		<a href="http://apply.6degreesinc.com/" target="_self">
			<div class="footer_nav_btn">
				apply
			</div><!-- apply -->
		</a>
		<a href="http://6degreesinc.com/about/">
			<div class="footer_nav_btn">
				about
			</div><!-- about -->
		</a>
		<a href="http://6degreesinc.com/team/">
			<div class="footer_nav_btn">
				team
			</div><!-- team -->
		</a>
		<a href="http://6degreesinc.com/services/">
			<div class="footer_nav_btn">
				services
			</div><!-- services -->
		</a>
		<a href="http://6degreesinc.com/news/">
			<div class="footer_nav_btn">
				news
			</div><!-- news -->
		</a>
		<a href="http://6degreesinc.com/teams/">
			<div id="teams" class="footer_nav_btn">
				teams
			</div><!-- teams -->
		</a>
	</div>
	<div id="copyright">
		Six Degrees Search Inc. ©2016
	</div>
</footer><!-- footer -->




