<nav>
	<div id="nav_toggle" class="mobile">
		<span class="fa fa-bars" aria-hidden="true"></span>
	</div>
	<div id="nav_btns_toggle">
	<div id="nav_holder">
		<a href="/" target="_self">
			<div class="nav_btn">
				home
			</div><!-- home -->
		</a>
		<a href="http://positions.6degreesinc.com/" target="_self">
			<div class="nav_btn">
				positions
			</div><!-- positions -->
		</a>
		<a href="http://apply.6degreesinc.com/" target="_self">
			<div class="nav_btn">
				apply
			</div><!-- apply -->
		</a>
		<a href="http://6degreesinc.com/about/" target="_self">
			<div class="nav_btn">
				about
			</div><!-- about -->
		</a>
		<a href="http://6degreesinc.com/team/" target="_self">
			<div class="nav_btn">
				team
			</div><!-- team -->
		</a>
		<a href="http://6degreesinc.com/services/" target="_self">
			<div class="nav_btn">
				services
			</div><!-- services -->
		</a>
		<a href="http://6degreesinc.com/news/" target="_self">
			<div class="nav_btn">
				news
			</div><!-- news -->
		</a>

		<a href="http://6degreesinc.com/contact/" target="_self">
			<div class="nav_btn">
				contact
			</div><!-- news -->
		</a>
		<a href="https://www.linkedin.com/company/202275?trk" target="_blank">
			<div type="linkedin" class="social_btn">
				<span class="fa fa-linkedin" aria-hidden="true" ></span>
				<span class="screen-reader-text">Linkedin</span>
			</div><!-- linkedin -->
		</a>
		<a href="https://www.instagram.com/6degreeschicago/" target="_blank">
			<div type="instagram" class="social_btn">
				<span class="fa fa-instagram" aria-hidden="true" ></span>
				<span class="screen-reader-text">Instagram</span>
			</div><!-- linkedin -->
		</a>
		<a href="https://www.facebook.com/6Degreesinc" target="_blank">
			<div type="facebook" class="social_btn">
				<span class="fa fa-facebook" aria-hidden="true" ></span>
				<span class="screen-reader-text">Facebook</span>
			</div><!-- linkedin -->
		</a>
		<a href="https://twitter.com/sixglobal" target="_blank">
			<div type="twitter" class="social_btn">
				<span class="fa fa-twitter" aria-hidden="true" ></span>
				<span class="screen-reader-text">Twitter</span>
			</div><!-- linkedin -->
		</a>

		<a href="https://www.linkedin.com/groups/112312" target="_blank">
				<div class="img_btn">
					<div class="img_btn_holder">
						<div class="img_btn_rest">
							<img src="template/images/spartan_btn_rest.png">
						</div>
						<div class="img_btn_roll">
							<img src="images/spartan_btn_roll.png">
						</div>
					</div>
				</div>
		</a>
	</div><!-- nav_holder -->
	</div><!-- nav_btns_toggle -->

</nav><!-- nav -->




