<div id="home">
	<div id="home_holder">
		<div id="home_anim">
		</div><!-- home_anim -->
		<div id="site_logo">
			<img src="template/images/site_logo.png" alt="6 Degrees Logo">
		</div><!-- site_logo -->
	</div><!-- home_holder -->
</div><!-- home -->



